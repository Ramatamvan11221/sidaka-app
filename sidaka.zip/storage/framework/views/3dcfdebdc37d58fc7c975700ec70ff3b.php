<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $value = $status->value ?? $status;

    // Format label
    $label = is_object($status) && method_exists($status, 'label')
        ? $status->label()
        : ucfirst(str_replace('_', ' ', (string) $value));

    // Design token per status — semua super soft, dot warna jadi fokus utama
    $style = match($value) {
        'pending', 'pending_tu'         => ['bg' => 'bg-amber-500/[0.08]',    'text' => 'text-amber-700',    'border' => 'border-amber-500/20',    'dot' => 'bg-amber-500'],
        'pending_kurikulum', 'approved' => ['bg' => 'bg-[#0A84FF]/[0.08]',    'text' => 'text-[#0055CC]',    'border' => 'border-[#0A84FF]/20',    'dot' => 'bg-[#0A84FF]'],
        'preparing'                    => ['bg' => 'bg-indigo-500/[0.08]',   'text' => 'text-indigo-700',   'border' => 'border-indigo-500/20',   'dot' => 'bg-indigo-500'],
        'ready'                        => ['bg' => 'bg-emerald-500/[0.08]',  'text' => 'text-emerald-700',  'border' => 'border-emerald-500/20',  'dot' => 'bg-emerald-500'],
        'completed'                    => ['bg' => 'bg-neutral-500/[0.06]',  'text' => 'text-neutral-700',  'border' => 'border-neutral-500/15',  'dot' => 'bg-neutral-500'],
        'borrowed'                     => ['bg' => 'bg-violet-500/[0.08]',   'text' => 'text-violet-700',   'border' => 'border-violet-500/20',   'dot' => 'bg-violet-500'],
        'returned'                     => ['bg' => 'bg-teal-500/[0.08]',     'text' => 'text-teal-700',     'border' => 'border-teal-500/20',     'dot' => 'bg-teal-500'],
        'rejected'                     => ['bg' => 'bg-rose-500/[0.08]',     'text' => 'text-rose-700',     'border' => 'border-rose-500/20',     'dot' => 'bg-rose-500'],
        'verified'                     => ['bg' => 'bg-emerald-500/[0.08]',  'text' => 'text-emerald-700',  'border' => 'border-emerald-500/20',  'dot' => 'bg-emerald-500'],
        default                        => ['bg' => 'bg-neutral-500/[0.06]',  'text' => 'text-neutral-600',  'border' => 'border-neutral-500/15',  'dot' => 'bg-neutral-400'],
    };
?>

<span class="inline-flex items-center gap-1.5 h-6 pl-2 pr-2.5 rounded-md
             border <?php echo e($style['bg']); ?> <?php echo e($style['text']); ?> <?php echo e($style['border']); ?>

             whitespace-nowrap">

    
    <span class="w-1.5 h-1.5 rounded-full shrink-0 <?php echo e($style['dot']); ?>"></span>

    
    <span class="font-mono text-[10px] font-medium uppercase tracking-wider">
        <?php echo e($label); ?>

    </span>

</span><?php /**PATH C:\xampp\htdocs\sidaka-app\resources\views/components/status-badge.blade.php ENDPATH**/ ?>