<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Detail Pengajuan - Admin SIDAKA']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Pengajuan - Admin SIDAKA']); ?>
     <?php $__env->slot('header', null, []); ?> Detail Pengajuan #<?php echo e($serviceRequest->request_number); ?> <?php $__env->endSlot(); ?>

    <?php
        $statusValue = is_object($serviceRequest->status) ? $serviceRequest->status->value : $serviceRequest->status;
    ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Detail Utama & Dokumen (2 Kolom) -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Information Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-200 pb-4">
                    <div>
                        <p class="text-xs font-semibold text-slate-400 uppercase">Nomor Pengajuan</p>
                        <h3 class="text-xl font-mono font-bold text-slate-900"><?php echo e($serviceRequest->request_number); ?></h3>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $serviceRequest->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($serviceRequest->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <div>
                        <p class="text-xs text-slate-500">Jenis Layanan</p>
                        <p class="font-semibold text-slate-800"><?php echo e($serviceRequest->serviceType->name ?? '-'); ?></p>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500">Tanggal Pengajuan</p>
                        <p class="font-semibold text-slate-800"><?php echo e($serviceRequest->created_at->format('d F Y H:i')); ?></p>
                    </div>
                </div>

                <div>
                    <p class="text-xs text-slate-500">Keperluan Pengajuan</p>
                    <p class="p-3 bg-slate-50 rounded-xl text-slate-700 text-sm mt-1 border border-slate-200"><?php echo e($serviceRequest->purpose ?? '-'); ?></p>
                </div>

                <?php if($serviceRequest->rejection_note || $serviceRequest->admin_notes): ?>
                    <div>
                        <p class="text-xs text-slate-500">Catatan Verifikasi / Penolakan</p>
                        <p class="p-3 bg-amber-50 rounded-xl text-amber-800 text-sm mt-1 border border-amber-200">
                            <?php echo e($serviceRequest->rejection_note ?? $serviceRequest->admin_notes); ?>

                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Dokumen yang Diajukan -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h4 class="font-bold text-slate-800 text-sm mb-4">Dokumen yang Diajukan</h4>
                <div class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $serviceRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                            <div>
                                <p class="font-semibold text-slate-800 text-sm"><?php echo e($item->document->title ?? 'Dokumen'); ?></p>
                                <p class="text-xs text-slate-400"><?php echo e($item->document->documentType->name ?? '-'); ?></p>
                            </div>
                            <?php if($item->document): ?>
                                <a href="<?php echo e(route('documents.stream', $item->document)); ?>" target="_blank" class="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold text-xs rounded-lg transition">
                                    Pratinjau File
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-xs text-slate-400 italic">Tidak ada rincian berkas terlampir.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar Informasi Pemohon & Aksi Status (1 Kolom) -->
        <div class="space-y-6">
            <!-- Informasi Pemohon -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3 text-sm">
                <h4 class="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2">Informasi Pemohon</h4>
                <div>
                    <p class="text-xs text-slate-400">Nama Siswa</p>
                    <p class="font-semibold text-slate-800"><?php echo e($serviceRequest->student->user->name ?? '-'); ?></p>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <p class="text-xs text-slate-400">NIS / NISN</p>
                        <p class="font-semibold text-slate-800 text-xs"><?php echo e($serviceRequest->student->nis ?? '-'); ?> / <?php echo e($serviceRequest->student->nisn ?? '-'); ?></p>
                    </div>
                    <div>
                        <p class="text-xs text-slate-400">Kelas</p>
                        <p class="font-semibold text-slate-800 text-xs"><?php echo e($serviceRequest->student->classInfo->name ?? '-'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Aksi Status Pengajuan Berjenjang -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h4 class="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2">Aksi Status Pengajuan</h4>

                
                <?php if(in_array($statusValue, ['pending_tu', 'pending'])): ?>
                    <div class="p-3 bg-amber-50 border border-amber-200 rounded-xl mb-3 text-xs text-amber-800">
                        <span class="font-semibold block">Tahap 1: Tata Usaha</span>
                        Periksa kelengkapan berkas fisik siswa sebelum meneruskan ke Kurikulum.
                    </div>
                    <form action="<?php echo e(route('admin.service-requests.verify-tu', $serviceRequest)); ?>" method="POST" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label class="block text-xs text-slate-500 mb-1">Catatan Penolakan (Wajib jika ditolak)</label>
                            <textarea name="rejection_note" rows="2" class="w-full p-2.5 rounded-xl border border-slate-300 text-xs outline-none focus:ring-2 focus:ring-amber-500" placeholder="Alasan penolakan berkas TU..."></textarea>
                        </div>
                        <div class="flex gap-2">
                            <button type="submit" name="action" value="approve" class="flex-1 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-xl transition">
                                ✓ Teruskan ke Kurikulum
                            </button>
                            <button type="submit" name="action" value="reject" class="py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl transition">
                                ✕ Tolak Berkas
                            </button>
                        </div>
                    </form>

                
                <?php elseif($statusValue === 'pending_kurikulum'): ?>
                    <div class="p-3 bg-blue-50 border border-blue-200 rounded-xl mb-3 text-xs text-blue-800">
                        <span class="font-semibold block">Tahap 2: Kurikulum</span>
                        Lakukan crosscheck data keabsahan akademik siswa sebelum legalisir diterbitkan.
                    </div>
                    <form action="<?php echo e(route('admin.service-requests.verify-kurikulum', $serviceRequest)); ?>" method="POST" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label class="block text-xs text-slate-500 mb-1">Catatan Penolakan (Wajib jika ditolak)</label>
                            <textarea name="rejection_note" rows="2" class="w-full p-2.5 rounded-xl border border-slate-300 text-xs outline-none focus:ring-2 focus:ring-blue-500" placeholder="Alasan penolakan Kurikulum..."></textarea>
                        </div>
                        <div class="flex gap-2">
                            <button type="submit" name="action" value="approve" class="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition">
                                ✓ Validasi &amp; Legalisir (Sah)
                            </button>
                            <button type="submit" name="action" value="reject" class="py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl transition">
                                ✕ Tolak
                            </button>
                        </div>
                    </form>

                
                <?php elseif(in_array($statusValue, ['verified', 'approved'])): ?>
                    <form action="<?php echo e(route('admin.service-requests.update-status', $serviceRequest)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="status" value="preparing">
                        <button type="submit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow transition">
                            📦 Siapkan Berkas Fisik (Preparing)
                        </button>
                    </form>

                <?php elseif($statusValue === 'preparing'): ?>
                    <form action="<?php echo e(route('admin.service-requests.update-status', $serviceRequest)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="status" value="ready">
                        <button type="submit" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow transition">
                            ✅ Tandai Siap Diambil (Ready)
                        </button>
                    </form>

                <?php elseif($statusValue === 'ready'): ?>
                    <div class="space-y-3">
                        <p class="text-xs text-emerald-700 font-medium">Berkas fisik telah siap! Klik tombol di bawah untuk menampilkan QR Code penyerahan di monitor.</p>
                        <a href="<?php echo e(route('admin.service-requests.qr-display', $serviceRequest)); ?>" target="_blank" class="block w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs text-center rounded-xl shadow-lg transition">
                            🖥️ Tampilkan QR Penyerahan di Monitor
                        </a>
                    </div>

                <?php elseif($statusValue === 'borrowed'): ?>
                    <form action="<?php echo e(route('admin.returns.store', $serviceRequest)); ?>" method="POST" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label class="block text-xs text-slate-500 mb-1">Catatan Pengembalian</label>
                            <input type="text" name="notes" placeholder="Kondisi fisik berkas saat dikembalikan..." class="w-full p-2.5 rounded-xl border border-slate-300 text-xs outline-none">
                        </div>
                        <button type="submit" class="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow transition">
                            🔄 Konfirmasi Pengembalian Rapor
                        </button>
                    </form>

                <?php else: ?>
                    <p class="text-xs text-slate-500 italic">Tidak ada aksi status lanjutan untuk status saat ini (<?php echo e(strtoupper($statusValue)); ?>).</p>
                <?php endif; ?>

                <?php if(in_array($statusValue, ['completed', 'borrowed', 'verified', 'ready'])): ?>
                    <a href="<?php echo e(route('service-requests.receipt', $serviceRequest)); ?>" target="_blank" class="block w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs text-center rounded-xl shadow transition">
                        📄 Cetak / Download Tanda Terima PDF
                    </a>
                <?php endif; ?>
            </div>

            <!-- Timeline Status / Riwayat -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h4 class="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2">Riwayat Transaksi</h4>
                <div class="space-y-3 relative pl-4 border-l-2 border-slate-200 text-xs">
                    <?php $__empty_1 = true; $__currentLoopData = $serviceRequest->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="relative">
                            <div class="absolute -left-[21px] top-1 w-2.5 h-2.5 bg-indigo-600 rounded-full"></div>
                            <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $history->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($history->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                            <p class="text-[10px] text-slate-400 mt-1"><?php echo e($history->created_at->format('d/m/Y H:i')); ?></p>
                            <?php if($history->notes): ?>
                                <p class="text-slate-600 mt-0.5"><?php echo e($history->notes); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-xs text-slate-400 italic">Belum ada catatan riwayat status.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sidaka-app\resources\views/admin/service_requests/show.blade.php ENDPATH**/ ?>