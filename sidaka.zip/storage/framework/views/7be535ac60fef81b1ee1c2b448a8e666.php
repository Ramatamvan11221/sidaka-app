<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Unggah Dokumen Admin - SIDAKA']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Unggah Dokumen Admin - SIDAKA']); ?>
     <?php $__env->slot('header', null, []); ?> Unggah Dokumen Siswa (Admin / Kurikulum / TU) <?php $__env->endSlot(); ?>

    <div class="max-w-3xl mx-auto rounded-2xl border border-black/[0.06] bg-white p-6 shadow-sm">
        <h2 class="text-lg font-semibold text-ink-900 mb-6">Unggah Berkas Baru</h2>

        
        <?php if($errors->any()): ?>
            <div class="mb-6 p-4 rounded-2xl bg-danger/5 border border-danger/20 text-danger">
                <p class="font-mono text-[10px] tracking-wider uppercase font-semibold mb-1.5">Gagal Mengunggah Dokumen:</p>
                <ul class="list-disc list-inside text-[12px] space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <form action="<?php echo e(route('admin.documents.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
            <?php echo csrf_field(); ?>

            
            <div>
                <label for="student_id" class="block text-xs font-medium text-ink-700 uppercase mb-1">Siswa</label>
                <select name="student_id" id="student_id" required class="w-full h-11 px-3 rounded-xl border border-black/[0.1] text-sm">
                    <option value="">— Pilih Siswa —</option>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>">
                            <?php echo e($student->user->name ?? 'Siswa'); ?> (NIS: <?php echo e($student->nis ?? '-'); ?> | <?php echo e($student->classInfo->name ?? '-'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label for="document_type_id" class="block text-xs font-medium text-ink-700 uppercase mb-1">Jenis Dokumen</label>
                <select name="document_type_id" id="document_type_id" required class="w-full h-11 px-3 rounded-xl border border-black/[0.1] text-sm">
                    <option value="">— Pilih Jenis Dokumen —</option>
                    <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-ink-700 mb-1.5">Kategori Berkas</label>
                <select name="category" required class="w-full rounded-xl border border-black/10 px-3.5 py-2.5 text-sm">
                    <option value="">-- Pilih Kategori --</option>
                    <option value="ijazah" <?php echo e(old('category') === 'ijazah' ? 'selected' : ''); ?>>Ijazah / SKL</option>
                    <option value="raport" <?php echo e(old('category') === 'raport' ? 'selected' : ''); ?>>Raport</option>
                    <option value="sertifikat" <?php echo e(old('category') === 'sertifikat' ? 'selected' : ''); ?>>Sertifikat</option>
                </select>
            </div>

            
            <div>
                <label for="title" class="block text-xs font-medium text-ink-700 uppercase mb-1">Judul Dokumen</label>
                <input type="text" name="title" id="title" placeholder="Contoh: Ijazah SMK / SKHUN / Sertifikat PKL" required class="w-full h-11 px-3 rounded-xl border border-black/[0.1] text-sm">
            </div>

            
            <div>
                <label for="file" class="block text-xs font-medium text-ink-700 uppercase mb-1">Berkas Dokumen (PDF/JPG/PNG)</label>
                <input type="file" name="file" id="file" required class="w-full p-2 border border-black/[0.1] rounded-xl text-sm">
            </div>

            <div class="pt-4 flex justify-end">
                <button type="submit" class="px-5 py-2.5 bg-ink-900 hover:bg-ink-700 text-white font-medium text-xs rounded-xl transition">
                    Unggah &amp; Verifikasi Dokumen
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sidaka-app\resources\views/admin/documents/create.blade.php ENDPATH**/ ?>